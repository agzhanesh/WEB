<!--?php
ini_set('display_errors', 1);
require( dirname(__FILE__) . '/wp-load.php' );

get_header();
? !-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DeliverMe</title>
<!-- link !-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- CSS -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/form-elements.css">
<link rel="stylesheet" href="assets/css/about-runner-partner.css">
<!-- font !-->
<link href="https://fonts.googleapis.com/css?family=Lato|Montserrat:400,700|Open+Sans" rel="stylesheet"> 
<!-- font !-->

<script>
$(document).ready(function () {
    $('.accordion-toggle').on('click', function(event){
    	event.preventDefault();
    	// create accordion variables
    	var accordion = $(this);
    	var accordionContent = accordion.next('.accordion-content');
    	
    	// toggle accordion link open class
    	accordion.toggleClass("open");
    	// toggle accordion content
    	accordionContent.slideToggle(250);
    	
    });
});
</script>
<!-- link !-->
</head>
<style>
.container-runner {
	padding-right: 15px;
	padding-left: 15px;
	margin-right: auto;
	margin-left: auto;
}
.center-con {
	width: 50%;
	margin: auto;
}
.center-con p {
margin: 0 0 10px;
}
@media (min-width: 768px) {
.container-runner {
	width: 750px;
}
}
@media (min-width: 992px) {
.container-runner {
	width: 970px;
}
}
@media (min-width: 1200px) {
.container-runner {
	width: 1170px;
}
}
.container {
	width: 100% !important;
	padding: 0 !important;
}
.container-form {
	width: 1170px !important;
	margin-left: auto;
	margin-right: auto;
	padding-left: 15px;
	padding-right: 15px;
	background-color: #fff;
	max-width: 100%;
	overflow: hidden;
	position: relative
}
.top_nav_out {
	display: none !important;
}
</style>
<body>
<!-- image section !-->
<div class="become-a-runner-img">
	<div class="banner-text">
		<h2 class="header-text">DELIVER PACKAGES, MAKE MONEY.</h2>
		<h4>More Freedom And Flexibility</h4>
		<br>
		<div><a href="/become-a-runner.php" class="apply-now-but">Apply now </a></div>
	</div>
	<div class="clearfix"></div>
</div>
<!-- image section !-->
<div class="container-runner"> 
	<!-- tab menu !-->
	<div class="text-center  header-text">
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 runner-step-link overview"> <a href="#why-become-a-runner" class="clr-333"> <img src="assets/img/over-view.png" class="runner-menu-icon"/> Overview </a> </div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 runner-step-link how-it-work"> <a href="#how-it-all-work" class="clr-333"> <img src="assets/img/box.png" class="runner-menu-icon"/> How It Works </a> </div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 runner-step-link faq"> <a href="#faq" class="clr-333"> <img src="assets/img/faq.png" class="runner-menu-icon"/> FAQ </a> </div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 runner-step-link apply"> <a href="#apply" class="clr-333"> <img src="assets/img/clipboard.png" class="runner-menu-icon"/> Apply </a> </div>
		<div class="clearfix"></div>
	</div>
	<!-- tab menu !--> 
	<!-- tab menu !-->
	<div id="why-become-a-runner" class="why-runner-bg">
		<h2 class="text-center why-becom-runner header-text">Why become a Runner?</h2>
		<!-- first row !--> 
		<!-- single !-->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="text-center col-lg-3 col-md-3 col-sm-3"><img src="assets/img/boss.png" class="why-runner-icon"/></div>
			<div class="col-lg-9 hei-175">
				<h2 class="why-runner-h2 header-text">Be Your Own Boss</h2>
				<p class="why-runner-hind">Work as a Runner on weekdays or weekends. Or both. Set flexible hours and create a schedule that works best for you.</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- single !--> 
		<!-- single !-->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="text-center col-lg-3 col-md-3 col-sm-3"><img src="assets/img/much-earn.png" class="why-runner-icon"/></div>
			<div class="col-lg-9 hei-175">
				<h2 class="why-runner-h2 header-text">Earn As Much As You Want</h2>
				<p class="why-runner-hind">The more you drive, the more you make. Earn extra with bonus awards and rewards</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- single !--> 
		<!-- single !-->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="text-center col-lg-3 col-md-3 col-sm-3"><img src="assets/img/consistent-pay.png" class="why-runner-icon"/></div>
			<div class="col-lg-9 hei-175">
				<h2 class="why-runner-h2 header-text">Consistent Pay</h2>
				<p class="why-runner-hind">Get paid weekly. Your money gets deposited directly to your bank account each week.</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- single !--> 
		<!-- first row !-->
		<div class="heigh">&nbsp;</div>
		<!-- second row !--> 
		<!-- single !-->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="text-center col-lg-3 col-md-3 col-sm-3"><img src="assets/img/guaranteed-rates.png" class="why-runner-icon"/></div>
			<div class="col-lg-9 hei-175">
				<h2 class="why-runner-h2 header-text">Guaranteed Rates</h2>
				<p class="why-runner-hind">Steady rates, no fare reductions. Promotional rates are compensated by the company.</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- single !--> 
		<!-- single !-->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="text-center col-lg-3 col-md-3 col-sm-3"><img src="assets/img/fun-comu.png" class="why-runner-icon"/></div>
			<div class="col-lg-9 hei-175">
				<h2 class="why-runner-h2 header-text">Fun Community</h2>
				<p class="why-runner-hind">The DeliverMe community is full of awesome, friendly people — customers and Runners alike.</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- single !--> 
		<!-- single !-->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="text-center col-lg-3 col-md-3 col-sm-3"><img src="assets/img/rewards-program.png" class="why-runner-icon"/></div>
			<div class="col-lg-9 hei-175">
				<h2 class="why-runner-h2 header-text">Rewards Program</h2>
				<p class="why-runner-hind">With a tiered rewards program, you make more the more you deliver with DeliverMe</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- single !-->
		<div class="clearfix"></div>
		<!-- second row !-->
		<div> </div>
		<div class="clearfix"></div>
	</div>
	<!-- tab menu !--> 
	<!-- who we looking for !-->
	<div class="who-we-look">
		<h2 class="text-center who-we-looking header-text">Who We're Looking For</h2>
		<p class="why-runner-hind text-center padding-50 who-hint-txt-clr">At DeliverMe we’re setting a new bar for package delivery, and that starts with you. Our runners are the face of the company, and the reason customers call us “life changing”. You might be a perfect fit, here’s what you need to join the team: </p>
		<div class="who-we-looking-option">
			<div class="center-con">
				<p><i class="fa fa-check who-we-looking-icon" aria-hidden="true"></i>Friendly, customer-oriented personality</p>
				<p><i class="fa fa-check who-we-looking-icon" aria-hidden="true"></i> Attention to detail, strong problem solving skills </p>
				<p><i class="fa fa-check who-we-looking-icon" aria-hidden="true"></i> Smartphone (iOS or Android) </p>
				<p><i class="fa fa-check who-we-looking-icon" aria-hidden="true"></i>Two Wheeler or Covered truck</p>
				<p><i class="fa fa-check who-we-looking-icon" aria-hidden="true"></i> Not afraid of cardboard boxes </p>
				<p><i class="fa fa-check who-we-looking-icon" aria-hidden="true"></i> Vehicle insurance and clean driving record </p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="who-we-looking-apply-but text-center"> <a href="/become-a-runner.php">Apply Now</a> </div>
		<div class="clearfix"></div>
	</div>
	<!-- who we looking for !--> 
	<!-- how it is work !-->
	<div id="how-it-all-work" class="why-runner-bg">
		<h2 class="text-center who-we-looking header-text">How It Works?</h2>
		<!-- section !-->
		<div class="text-center">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="runner-act"><img src="assets/img/schedule.png" class="why-runner-icon"/></div>
				<div>
					<h3 class="header-text">Choose your own schedule</h3>
					<p>Tell us when you want to make deliveries.</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="runner-act"><img src="assets/img/package.png" class="why-runner-icon"/></div>
				<div>
					<h3 class="header-text">Pick up <br>
						packages</h3>
					<p>Arrive at a vendor's store or warehouse and pickup the package.</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="runner-act"><img src="assets/img/destination.png" class="why-runner-icon"/></div>
				<div>
					<h3 class="header-text">Reach your <br>
						destination</h3>
					<p>The DeliverMe DeliverMe runner app will show you where to deliver packages.</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="runner-act"><img src="assets/img/gift.png" class="why-runner-icon"/></div>
				<div>
					<h3 class="header-text">Deliver packages to customers</h3>
					<p>Arrive at a customer's place to hand-deliver their purchase.</p>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- section !-->
		<div class="clearfix"></div>
	</div>
	<!-- how it is work !--> 
	<!-- ask question !-->
	<div id="faq" class="accordion-container">
		<h2 class="text-center who-we-looking header-text">Frequently Asked Questions</h2>
		<!-- section !-->
		<div class="text-center">
			<div class="col-lg-4">
				<div>
					<h3 class="header-text blue-hrd-text">Background Info</h3>
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">What is DeliverMe?</a>
						<div class="accordion-content"> DeliverMe is a technology company and delivery service that simplifies how people receive and return the items they buy online.
							
							The DeliverMe app allows you to schedule a delivery or pickup time for your online purchases (or anything else) to your door at your convenience. </div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">What does being a DeliverMe Runner entail?</a>
						<div class="accordion-content"> Your job as a DeliverMe Runner will involve picking up packages from a DeliverMe vendors using your own vehicle and then dropping them off to customers.
							
							After picking up packages for that evening's delivery, you are assigned a route, and the DeliverMe Runner app tells you where to make stop deliver the package. </div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">What does it take to become a DeliverMe Runner?</a>
						<div class="accordion-content"> We prioritize hiring friendly people with a strong background in customer service who want to be a part of a startup transforming the ecommerce delivery space.
							
							Our DeliverMe Runners strive to go 'above and beyond' the services that other courier companies provide. </div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">Which cities can i apply to become a DeliverMe Runner?</a>
						<div class="accordion-content">You can be a DeliverMe Runner for DeliverMe if you live in Coimbatore, Chennai, Bengaluru and Mumbai City metro areas.</div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">Does DeliverMe using bikes and scooters?</a>
						<div class="accordion-content"> DeliverMe Runners use their own bikes to deliver packages.
							
							Runners can also deliver using Auto, Pickup Truck, MiniVan, Car, Cycle - Bike or They can even walk. </div>
					</div>
					<!-- single Question !--> 
				</div>
			</div>
			<div class="col-lg-4">
				<div>
					<h3 class="header-text blue-hrd-text">Signing up</h3>
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">What type of smartphone do I need to download the DeliverMe app?</a>
						<div class="accordion-content"> To deliver with DeliverMe, you’ll need to have an iPhone 5 or newer, running iOS 9.0 or higher.
							
							The Runner app is also available for Android phones 5.0, or above, with a flash-enabled phone camera for scanning. </div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">What type of vehicle do I need?</a>
						<div class="accordion-content">DeliverMe Runners must have a vehicle such as a Bike or Two wheeler or Mini Van or Covered truck. </div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">How does the application process work?</a>
						<div class="accordion-content">We're constantly looking for friendly, reliable people to join our team! Simply fill out the application on this page and someone from our local office will contact you if we think you're a good fit!</div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">How long will it take to you to respond after I sign up?</a>
						<div class="accordion-content"> Response time varies by city. We prioritize hiring friendly, customer service-oriented Runners.
							
							So to stand out amongst the competition (and receive a quicker response) make sure you highlight relevant skills! </div>
					</div>
					<!-- single Question !--> 
				</div>
			</div>
			<div class="col-lg-4">
				<div>
					<h3 class="header-text blue-hrd-text">What to expect</h3>
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">How many days or hours will I need to work each week?</a>
						<div class="accordion-content"> At DeliverMe, we understand everyone has busy lives and plans frequently change.
							
							We provide our Runners with complete control over the days they wish to work As a contractor. You can choose when to work. Be your own Boss!. </div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">Is there a minimum number of deliveries that I need to make to remain eligible to deliver with DeliverMe?</a>
						<div class="accordion-content">You do not need to make a minimum number of deliveries to remain eligible to deliver with DeliverMe.</div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">What do I need to wear?</a>
						<div class="accordion-content"> Our Runners should look presentable and professional.
							
							We're happy to provide you with DeliverMe swag to wear while delivering if you'd like! </div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">Do I need to bring anything with me?</a>
						<div class="accordion-content"> We provide you with all the gear that will help you to complete easch delivery!
							As an independent contractor, you are free to use anything to help in your delivery process. </div>
					</div>
					<!-- single Question !--> 
				</div>
			</div>
			<div class="col-lg-4">
				<div>
					<h3 class="header-text blue-hrd-text">Runner Screening</h3>
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">Do I have to agree to a background check?</a>
						<div class="accordion-content">Yes, successful completion of a background check is a requirement to becoming a Runner.</div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">How long will my background check take?</a>
						<div class="accordion-content"> Background checks typically take between one to two business days and you'll receive a copy once it's complete.
							
							If you have questions about your background check, please reach to us <a href="mailto:support@deliverme.co.in" target="_top">support@deliverme.co.in</a> </div>
					</div>
					<!-- single Question !--> 
				</div>
			</div>
			<div class="col-lg-4">
				<div>
					<h3 class="header-text blue-hrd-text">Earnings</h3>
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">How will I get paid?</a>
						<div class="accordion-content">All Runners are paid via direct bank deposit.</div>
					</div>
					<!-- single Question !--> 
					<!-- single Question !-->
					<div> <a href="#" class="accordion-toggle">When will I get paid?</a>
						<div class="accordion-content">DeliverMe Runners are typically paid every Friday.
							You can also request for a payment anytime and it will be deposited in your bank, The following business day. </div>
					</div>
					<!-- single Question !--> 
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- section !-->
		<div class="clearfix"></div>
	</div>
	<!-- ask question !--> 
	
</div>
<!-- apply now !-->
<div id="apply" class="text-center apply-now">
	<h3 class="header-text">Become a Runner</h3>
	<div class=""><a href="/become-a-runner.php" class="apply-now-but">Apply now</a></div>
	<div class="clearfix"></div>
</div>
<!-- apply now !-->
</body>
</html>
<?php
get_footer();
 ?>