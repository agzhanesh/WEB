<!--?php
ini_set('display_errors', 1);
require( dirname(__FILE__) . '/wp-load.php' );

get_header();
?!-->
<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Deliver Me - Become a Runner</title>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<!-- CSS -->
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
		<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
		<link rel="stylesheet" href="assets/css/style.css">
		<!-- date picker !-->
		<link rel="stylesheet" href="assets/date-picker/css/bootstrap-datepicker3.css"/>
		<script type="text/javascript" src="assets/date-picker/js/bootstrap-datepicker.min.js"></script>

		<script>
            $(document).ready(function () {
                $('#runnerregistration').click(function () {
                    $("#showimage").css("display", "block");
                    var firstname=$('#first-name').val();
                    var lastname=$('#last-name').val();
                    var email=$('#email-id').val();
                    var password=$('#password').val();
                    var contactno=$('#contact-number').val();
                    var qualification=$('#qualification').val();
                    var department=$('#department').val();
                    var address1=$('#address-line-one').val();
                    var address2=$('#address-line-two').val();
                    var city=$('#city').val();
                    var state=$('#state').val();
                    var country=$('#country').val();
                    var zipcode=$('#zipcode').val();
                    var licensename=$('#name-on-license').val();
                    var licenseno=$('#license-number').val();
                    var licensestartdate=$('#startDate').val();
                    var licenseenddate=$('#endDate').val();
                    var vehicleno=$('#vehicle-number').val();
                    var insuranceno=$('#insurance-number').val();
                    var insurancevalidity=$('#insurance-validity').val();
                    var profilephoto=$("#profile_image").prop("files")[0];   // Getting the properties of file from file field
                    var licenseimage=$("#licensee_image").prop("files")[0];
                    var rcbookimage=$('#vehicle-registration-certificate').prop("files")[0];
                    var insuranceimage=$('#insurance_image').prop("files")[0];
                    var form_data=new FormData();                  // Creating object of FormData class
                    form_data.append("profile", profilephoto);              // Appending parameter named file with properties of file_field to form_data
                    form_data.append("firstname", firstname);
                    form_data.append("lastname", lastname);
                    form_data.append("email", email);
                    form_data.append("contactno", contactno);
                    form_data.append("qualification", qualification);
                    form_data.append("password", password);
                    form_data.append("department", department);
                    form_data.append("address1", address1);
                    form_data.append("address2", address2);
                    form_data.append("city", city);
                    form_data.append("state", state);
                    form_data.append("country", country);
                    form_data.append("zipcode", zipcode);
                    form_data.append("licensename", licensename);
                    form_data.append("licenseno", licenseno);
                    form_data.append("licensestartdate", licensestartdate);
                    form_data.append("licenseenddate", licenseenddate);
                    form_data.append("vehicleno", vehicleno);
                    form_data.append("insuranceno", insuranceno);
                    form_data.append("insurancevalidity", insurancevalidity);
                    form_data.append("licenseimage", licenseimage);
                    form_data.append("rcbookimage", rcbookimage);
                    form_data.append("insuranceimage", insuranceimage);
                    //console.log(contactno);
                    $.ajax({
                        type: "POST",
                        url: "https://api.deliverme.co.in/public/api/addrunners",
                        //  dataType: 'script',
                        crossDomain: true,
						async:false,
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: form_data, // Setting the data attribute of ajax with file_data
                        success: function (response) {
							if(response.success){
                            $("#showimage").css("display", "none");
                            $("#finalform").css("display", "none");
                            $("#resultsuccess").css("display", "block");
							}
							else{
                            $("#showimage").css("display", "none");
                            $("#finalform").css("display", "none");
                            $("#resulterror").css("display", "block");								
							}
                            /* $('#resultsuccess').html(response.success); )*/
                            //console.log(response);
                        },
                        error: function (response) {
                            $("#showimage").css("display", "none");
                            $("#finalform").css("display", "none");
                            $("#resulterror").css("display", "block");
                            /* $('#resultsuccess').html(response.success); )*/
                            console.log(response);
                        }
                    });
                });
            });
		</script>

		<script>
            $(function () {
                $('#profile_image').change(function (e) {

                    var img=URL.createObjectURL(e.target.files[0]);
                    $('.profile').attr('src', img);
                });
            });
            $(function () {
                $('#licensee_image').change(function (e) {

                    var img=URL.createObjectURL(e.target.files[0]);
                    $('.license').attr('src', img);
                });
            });
            $(function () {
                $('#vehicle-registration-certificate').change(function (e) {

                    var img=URL.createObjectURL(e.target.files[0]);
                    $('.registration').attr('src', img);
                });
            });
            $(function () {
                $('#insurance_image').change(function (e) {

                    var img=URL.createObjectURL(e.target.files[0]);
                    $('.insurance').attr('src', img);
                });
            });
		</script>
	</head>

	<body>
		<!-- Top content -->
		<div class="top-content">
			<div class="inner-bg">
				<div class="container">
					<h3 class="becom-header">Become a Runner</h3>
					<!--<div class="row" style="margin:auto;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </div> -->
					<div class="row" style="margin:auto;">
						<div class="col-lg-12 form-box" id="finalform">
							<div id="showimage" style="display:none;width:69px;height:89px;position:absolute;top:50%;left:50%;padding:2px;"><img src='assets/img/loading.png' width="64" height="64" /></div>
							<section role="form"  class="registration-form">
								<fieldset>
									<div class="form-top">
										<div class="form-top-left">
											<h3>Personal Information</h3>
										<!--	<div class="desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </div>-->
										</div>
										<div class="form-top-right"> <i class="fa fa-user"></i> </div>
									</div>
									<div class="form-bottom">
										<!-- single row !-->
										<div>
											<div class="form-group col-lg-6 noleft-padding">
												<label class="sr-only1" for="first-name">First name</label>
												<input type="text" name="first-name" placeholder="First name..." class="first-name form-control" id="first-name">
											</div>
											<div class="form-group  col-lg-6 noright-padding">
												<label class="sr-only1" for="last-name">Last name</label>
												<input type="text" name="last-name" placeholder="Last name..." class="last-name form-control" id="last-name">
											</div>
											<div class="clearfix"></div>
										</div>
										<!-- single row !-->

										<!-- single row !-->
										<div>
											<div class="form-group col-lg-6 noleft-padding">
												<label class="sr-only1" for="email-id">Email ID</label>
												<input type="text" name="email-id" placeholder="Email ID..." class="email-id form-control" id="email-id">
											</div>
											<div class="form-group  col-lg-6 noright-padding">
												<label class="sr-only1" for="contact-number">Contact Number</label>
												<input type="text" name="contact-number" placeholder="Contact Number..." class="contact-number form-control" id="contact-number">
											</div>
											<div class="clearfix"></div>
										</div>
										<!-- single row !-->
										<!-- single row !-->
										<div>
											<div class="form-group col-lg-6 noleft-padding">
												<label class="sr-only1" for="password">Password</label>
												<input type="password" name="password" placeholder="Password..." class="password form-control" id="password">
											</div>
											<div class="form-group  col-lg-6 noright-padding">
												<label class="sr-only1" for="confirm-password">Confirm Password</label>
												<input type="password" name="confirm-password" placeholder="Confirm Password..." class="confirm-password form-control" id="confirm-password">
											</div>
											<div class="clearfix"></div>
										</div>
										<!-- single row !-->
										<!-- single row !-->
										<div class="form-group  col-lg-12 no-padding">
											<div class="col-lg-6 noleft-padding">
												<label class="sr-only1" for="qualification">Qualification</label>
												<input type="text" name="qualification" placeholder="Qualification..." class="qualification form-control" id="qualification">
											</div>
											<div class="col-lg-6 noright-padding">
												<label class="sr-only1" for="department">Department</label>
												<input type="text" name="department" placeholder="Department..." class="department form-control" id="department">
											</div>

											<div class="clearfix"></div>
										</div>
										<!-- single row !-->
										<!-- single row !-->
										<div class="col-lg-12 noright-padding">
											<label class="sr-only1 profile-photo-label" for="profile-photo">Profile Photo</label>
											<div style=" text-align: center;" class="profile-photo"> <img src="assets/img/backgrounds/default-profile.png" class="profile" style="max-width:100%; height:120px;"> </div>
											<input type="file" id="profile_image" style="height: 150px;
												   margin-top: -150px;
												   opacity: 0; width: 150px;">
											<div class="clearfix"></div>
										</div>

										<!-- single row !-->

										<div class=" col-lg-12">
											<button id="personal-next" type="button" class="btn btn-next pull-right">Next</button>
										</div>
										<div class="clearfix"></div>
									</div>
								</fieldset>
								<fieldset>
									<div class="form-top">
										<div class="form-top-left">
											<h3>Contact Information</h3>
										</div>
										<div class="form-top-right"> <i class="fa fa-map-marker"></i> </div>
									</div>
									<div class="form-bottom">
										<!-- single row !-->
										<div class="form-group  col-lg-12 no-padding">
											<label class="sr-only1" for="address-line-one">Address Line one</label>
											<input type="text" name="address-line-one" placeholder="Address Line one..." class="address-line-one form-control" id="address-line-one">
										</div>
										<!-- single row !-->
										<!-- single row !-->
										<div class="form-group  col-lg-12 no-padding">
											<label class="sr-only1" for="address-line-two">Address Line Two</label>
											<input type="text" name="address-line-two" placeholder="Address Line Two..." class="address-line-two form-control" id="address-line-two">
										</div>
										<!-- single row !-->
										<!-- single row !-->
										<div class="form-group  col-lg-12 no-padding">
											<div class="col-lg-4 noleft-padding">
												<label class="sr-only1" for="city">City</label>
												<select class="city form-control" id="city">
													<option>Coimbatore</option>
													<option>Chennai</option>
												</select>
											</div>
											<div class="col-lg-4 no-padding">
												<label class="sr-only1" for="state">State</label>
												<select class="state form-control" id="state">
													<option>Tamil Nadu</option>
												</select>
											</div>
											<div class="col-lg-4 noright-padding">
												<label class="sr-only1" for="country">Country</label>
												<select class="country form-control" id="country">
													<option>India</option>
												</select>
											</div>
											<div class="clearfix"></div>
										</div>
										<!-- single row !-->

										<!-- single row !-->
										<div class="form-group  col-lg-12 no-padding">
											<label class="sr-only1" for="zip-code">Zip Code</label>
											<input type="text" name="zip-code" placeholder="Zipcode..." class="zip-code form-control" id="zip-code">
										</div>
										<!-- single row !-->

										<div>

											<!-- button !-->
											<div>
												<div class="pull-left">
													<button class="btn btn-previous" type="button">Previous</button>
												</div>
												<div class="pull-right">
													<button type="button" class="btn btn-next">Next</button>
												</div>
												<div class="clearfix"></div>
											</div>
											<!-- button !-->

										</div>
									</div>
								</fieldset>
								<fieldset>
									<div class="form-top">
										<div class="form-top-left">
											<h3>Drivers License</h3>
										</div>
										<div class="form-top-right"> <i class="fa fa-motorcycle"></i> </div>
									</div>
									<div class="form-bottom">
										<!-- single row !-->
										<div>
											<div class="form-group col-lg-6 noleft-padding">
												<label class="sr-only1" for="name-on-license">Name on license</label>
												<input type="text" name="name-on-license" placeholder="Name on license..." class="name-on-license form-control" id="name-on-license">
											</div>
											<div class="form-group  col-lg-6 noright-padding">
												<label class="sr-only1" for="license-number">License number</label>
												<input type="text" name="license-number" placeholder="License number..." class="license-number form-control" id="license-number">
											</div>
											<div class="clearfix"></div>
										</div>

										<div>
											<div class="form-group col-lg-6 noleft-padding">
												<label for="startDate" class="sr-only1">start Date</label>
												<input type="text" class="form-control" id="startDate" value="07/01/2015">
											</div>
											<div class="form-group col-lg-6 noright-padding">
												<label for="startDate" class="sr-only1">end Date</label>
												<input type="text" class="form-control" id="endDate" value="07/01/2015">
											</div>
											<div class="clearfix"></div>
										</div>
										<!-- single row !-->
										<!-- single row !-->
										<div>
											<div class="form-group col-lg-4 noleft-padding">
												<label class="sr-only1" for="vehicle-number">Vehicle number</label>
												<input type="text" name="vehicle-number" placeholder="Vehicle number..." class="vehicle-number form-control" id="vehicle-number">
											</div>
											<div class="form-group  col-lg-4 no-padding">
												<label class="sr-only1" for="insurance-number">Insurance number</label>
												<input type="text" name="insurance-number" placeholder="Insurance number..." class="insurance-number form-control" id="insurance-number">
											</div>
											<div class="form-group  col-lg-4 noright-padding">
												<label class="sr-only1" for="insurance-validity">Insurance validity</label>
												<input type="text" name="insurance-validity" placeholder="Insurance validity..." class="insurance-validity form-control" id="insurance-validity">
											</div>
											<div class="clearfix"></div>
										</div>
										<!-- single row !-->
										<!-- single row !-->
										<div class="form-group col-lg-12 no-padding">
											<div class="col-lg-4 noleft-padding">
												<label class="sr-only1 profile-photo-label" for="license">License</label>
												<div style="text-align:center" class="profile-photo"> <embed  src="assets/img/backgrounds/default-license.png" class="license" style="max-width:100%; height:120px;"/> </div>
												<input type="file" id="licensee_image" style="height: 150px;
													   margin-top: -150px;
													   opacity: 0; width: 150px;">

											</div>
											<div class="col-lg-4 noleft-padding">
												<label class="sr-only1 profile-photo-label" for="license">Vehicle registration certificate</label>
												<div style="text-align:center" class="profile-photo"> <embed  src="assets/img/backgrounds/default-registration.png" class="registration" style="max-width:100%; height:120px;"/> </div>
												<input type="file" id="vehicle-registration-certificate" style="height: 150px;
													   margin-top: -150px;
													   opacity: 0; width: 150px;">

											</div>
											<div class="col-lg-4 noright-padding">
												<label class="sr-only1 profile-photo-label" for="insurance">Insurance</label>
												<div style="text-align:center" class="profile-photo"> <embed  src="assets/img/backgrounds/default-insurance.png" class="insurance" style="max-width:100%; height:120px;"/> </div>

												<input type="file" id="insurance_image" style="height: 150px;
													   margin-top: -150px;
													   opacity: 0; width: 150px;">

											</div>
											<div class="clearfix"></div>
										</div>
										<!-- single row !-->
										<div>

											<!-- button !-->
											<div>
												<div class="pull-left">
													<button class="btn btn-previous" type="button">Previous</button>
												</div>
												<div class="pull-right">
													<button type="button" class="btn btn-next">Next</button>
												</div>
												<div class="clearfix"></div>
											</div>
											<!-- button !-->

										</div>
									</div>
								</fieldset>
								<fieldset>
<div id="finalform" class="form-top">
										<div class="form-top-left">
											<h3>Background Check Disclosure</h3>
										</div>
										<div class="form-top-right"> <i class="fa fa-check-square-o"></i> </div>
									</div>
									<div class="form-bottom">
										<div class="form-group">
											<div class="desc">DeliverMe will orderconsumer reports about you from a consumer reporting agancy to access your proposal to enter into
											an independent contractor relationship with DeliverMe. A consumer report is a type of background check in  which information, including criminal background,
											driving records,character,general reputation,personel characteristics, and mode of living about you is gathered by a consumer reporting agency.
											DeliverMe may also order additional checks on you during any contractual engagement. </div>
										</div>

									</div>
																		<div id="finalform" class="form-top">
										<div class="form-top-left">
											<h3>Background Check Authorization</h3>
										</div>
										<div class="form-top-right"> <i class="fa fa-check-square-o"></i> </div>
									</div>
									<div class="form-bottom">
										<div class="form-group">
											<div class="desc">By my electronic signature below, I confirm i reviewed allbackground check disclosures and authorize DeliverMe to order consumer reports about me.
											I also agreed that, to the fullest extent allow by law, DeliverMe may order additional consumer reports without a further authorization during any engaements with DeliverMe. To the fullest extent allowed by law, I also authorize consumer reporting agency 
to investigate and verify information about me including my personel details, qualification, driver records and others. I understand and agree that electronic signature shall be binding just like a signature in ink.
											</div>
										</div>
										<div class="form-group">
								<div class="col-lg-1">
								<div class="form-top-right" style="color:#25AE88 !important;"> <i class="fa fa-check-square-o"></i> </div>
								</div>
								<div class="col-lg-11" style="margin-top: 20px;">
											<div class="desc"> I acknowledge that i have read, understand and agree to this "Background Check Authorization" and state law disclosures, and I authorize DeliverMe to custom reports relating to me. </div>
										</div>
										<div class="clearfix"></div>
										</div>
<div class="text-center">
											<!-- button !-->
											<div>
												<div class="pull-left">
													<button class="btn btn-previous" type="button">Previous</button>
												</div>
												<div class="pull-right">
													<button class="btn" type="submit" id="runnerregistration">Submit</button>
												</div>
												<div class="clearfix"></div>
											</div>
											<!-- button !-->
										</div>
									</div>

										
								</fieldset>
							</section>
						</div>
						<div id="resultsuccess" style="border-radius: 3px; box-shadow: 0 0 3px #444; display: none;">
							<div class="form-top">
								<div class="form-top-left">
									<h3 style="color:#1abc9c; font-weight:bold;">Registration successful</h3>
								</div>
								<div class="form-top-right"> <i class="fa fa-check-circle" style="color:#1abc9c"></i> </div>
							</div>
							<div class="form-bottom">
								<div class="form-group">
									<div class="desc">
										<p>Thanks for your interest.</p>
										<p>DeliverMe team will review your profile and revert you shortly. </p>
									</div>
								</div>
								<div class="text-center">
									<!-- button !-->
									<div>
										<div class="pull-right">
											<a href="/">
												<button class="btn pull-right" type="submit">Back to Home</button>
											</a>
										</div>
										<div class="clearfix"></div>
									</div>
									<!-- button !-->
								</div>
							</div>
						</div>
						<div id="resulterror" style="border-radius: 3px; box-shadow: 0 0 3px #444; display: none;">
							<div class="form-top">
								<div class="form-top-left">
									<h3 style="color:#ff0000; font-weight:bold;">Registration fail please try again</h3>
								</div>
								<div class="form-top-right"> <i class="fa fa-exclamation-circle" style="color:#ff0000"></i> </div>
							</div>
							<div class="form-bottom">
								<div class="form-group">
									<div class="desc">
										<p>Thanks for your interest.</p>
										<p>Your Email ID already registered with us. Please check your email and try again. </p>
									</div>
								</div>
								<div class="text-center">
									<!-- button !-->
									<div>
										<div class="pull-right">
											<a href="/become-a-runner.php">
												<button class="btn pull-right" type="submit">Try Again</button>
											</a>
										</div>
										<div class="clearfix"></div>
									</div>
									<!-- button !-->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Javascript -->

		<script src="assets/js/jquery-1.11.1.min.js"></script>
		<script src="assets/bootstrap/js/bootstrap.min.js"></script>
		<script src="assets/js/jquery.backstretch.min.js"></script>

		<script src="assets/js/retina-1.1.0.min.js"></script>
		<script src="assets/js/scripts.js"></script>
		<style>
			.container{
				width:100% !important;
				padding:0 !important;
			}
			.container-form{
				width:1170px !important;
				margin-left: auto;
				margin-right: auto;
				padding-left: 15px;
				padding-right: 15px;
				background-color: #fff;
				max-width: 100%;
				overflow: hidden;
				position: relative
			}
			.top_nav_out{
				display:none !important;
			}
		</style>

<!--?php
get_footer();
 ?!-->