<!--?php
ini_set('display_errors', 1);
require( dirname(__FILE__) . '/wp-load.php' );

get_header();
? !-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DeliverMe</title>
<!-- link !-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<!-- CSS -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet"> 
		<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
		<link rel="stylesheet" href="assets/css/about-runner-partner.css">
		<!-- date picker !-->
<!-- font !-->
<link href="https://fonts.googleapis.com/css?family=Lato|Montserrat:400,700|Open+Sans" rel="stylesheet"> 
<!-- font !-->

<!-- link !-->
</head>
<style>

.container-partner {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
@media (min-width: 768px) {
  .container-partner {
    width: 750px;
  }
}
@media (min-width: 992px) {
  .container-partner {
    width: 970px;
  }
}
@media (min-width: 1200px) {
 .container-partner {
    width: 1170px;
  }
}



			.container{
				width:100% !important;
				padding:0 !important;
			}
			.container-form{
				width:1170px !important;
				margin-left: auto;
				margin-right: auto;
				padding-left: 15px;
				padding-right: 15px;
				background-color: #fff;
				max-width: 100%;
				overflow: hidden;
				position: relative
			}
			.top_nav_out{
				display:none !important;
			}
		</style>
<body>
<!-- banner !-->
<!-- inner banner !-->
<div class="partner-banner">
<div class="container">
<div class="partner-banner-text">
<h2 class="header-text">Partner With DeliverMe</h2>
<h4>Delivery and logistics, solved.</h4>
<div><a href="/become-a-partner.php" class="apply-now-but">Sign up now</a></div>
</div>
</div>
<div class="clearfix"></div>
</div>
<!-- inner banner !-->
<div class="container-partner">

<!-- banner !-->
<!--partner count !-->
<div class="partner-count text-center">
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
<h1 class="header-text">1,000+</h1>
<h4>businesses that partner<br>
with DeliverMe </h4>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
<h1 class="header-text">10+</h1>
<h4>number of cities<br>
we operate in </h4>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
<h1 class="header-text">10,000+</h1>
<h4>deliveries per month<br>
from local businesses </h4>
</div>
<div class="clearfix"></div>
</div>
<!--partner count !-->
<!-- section !-->
<div>
<div class="container text-center">
<div class="col-lg-12 move-your-business">
<div class="move-bus-forward">
<div class="increase-busi"><img src="assets/img/analysis.png"/></div></div>
<h3 class="font-size-24 header-text">Move Your Business Forward</h3>
<p>It's no wonder thousands of merchants work with DeliverMe to power local deliveries. Tap into the nation's largest on-demand delivery network and start bringing your customers the products they love in a matter of minutes.</p>
</div>
<div>
</div>
<!-- try col !-->
<div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    <div class="increase-busi"><img src="assets/img/route1.png"/></div>
<h3 class="font-size-24 header-text">Expand Your Footprint</h3>
<p>Reach customers in new neighborhoods across the city</p>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    <div class="increase-busi"><img src="assets/img/brainstorming.png"/></div>
<h3 class="font-size-24 header-text">Gain New Customers</h3>
<p>Increase your visibility with a customized digital storefront</p>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    <div class="increase-busi"><img src="assets/img/graph.png"/></div>
<h3 class="font-size-24 header-text">Grow Revenue Faster</h3>
<p>On average, businesses see a 4X increase in orders after partnering with DeliverMe</p>
</div>
<div class="clearfix"></div>
</div>
<!-- try col !-->
</div>

</div>
<!-- section !-->



</div>
<!-- Experience !-->
<div class="experience-con">
<div class="container text-center">
<div>
 <div class="exper-icon"><img src="assets/img/bike.png"></div>
<h2 class="header-text">The DeliverMe Experience</h2>
<div style="width:80%; margin:auto;">
<p>We understand that when it comes to your brand, customer experience is key. Which is why we handle every detail - from carefully vetting our drivers to ensuring your product is delivered in a fresh and timely fashion - so you don't have to. That's our promise to you, 24/7.</p><div class="clearfix"></div><p></p>
<div class="clearfix"></div>
</div>
<div class=" col-lg-12">
<a href="/become-a-partner.php" class="apply-now-but">Sign up now</a>
</div>
</div>
</div>
<div class="clearfix"></div>
</div>
<!-- Experience !-->
</body>
</html>

<?php
get_footer();
 ?>
